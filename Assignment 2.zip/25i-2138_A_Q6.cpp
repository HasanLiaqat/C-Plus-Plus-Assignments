#include <iostream>
using namespace std;
int main()
{
  int choice;	
  unsigned long long warrior=0;     // FULL 64 BIT DATA
  
  cout<<"\n-----MENU-----\n"<<endl;
  cout<<"1 - Display attributes"<<endl;
  cout<<"2 - Check Skill ( 1 - 8 )"<<endl;
  cout<<"3 - Grant Skill ( 1 - 8 )"<<endl;
  cout<<"4 - Revoke Skill ( 1 - 8 )"<<endl;
  cout<<"5 - Improve attributes"<<endl;
  cout<<"6 - Level Up"<<endl;
  cout<<"0 - EXIT"<<endl;
  
  cout<<"\nChoice: ";
  cin>> choice;
  cout<<"\n";
  
  if ( choice<0 || choice>6 )
{	cout<<"Invalid Choice!"<<endl;
	return 0;
}
  
  unsigned long long gold=20;
  unsigned long long level=1;
  unsigned long long skills=0;
  unsigned long long wisdom=0;      // INDIVIDUAL ATTRIBUTES
  unsigned long long strenght=0;
  unsigned long long defence=0;
  unsigned long long agility=0;	
  unsigned long long honor=0;
  
  warrior = (honor<<56) | (agility<<48) | (defence<<40) | (strenght<<32) | (wisdom<<24) | (skills<<16) | (gold<<8) | level;


  if ( choice == 1)
{	cout<<"---Warrior Attributes---"<<endl;
	cout<<"Level: "<< int (level) << endl;
	cout<<"Gold: "<< int (gold) << endl;
	cout<<"Skills: "<< int (skills) << endl;
        cout<<"Wisdom: "<< int (wisdom) << endl;
        cout<<"Strenght: "<< int (strenght) << endl;
        cout<<"Defence: "<< int (defence) << endl;
        cout<<"Agility: "<< int (agility) << endl;
        cout<<"Honor: "<< int (honor) << endl;
        
}
	
  else if ( choice == 2 )
{  	int skillnum;
  	cout<<"Enter the Skill number ( 1 - 8 ): ";
  	cin>> skillnum;
  	
  	if ( skillnum<1 || skillnum>8 )
 {	cout<<"Invalid Skill number"<<endl;
 	return 0;
 }
        unsigned long long mask = 1ULL << ( 16 + ( skillnum - 1 ) );      // CREATING A MASK FOR SPECIFIC SKILL BIT ( 16-23 )
        
        if ( warrior & mask )
        cout<<"Skill "<< skillnum <<" is Active"<<endl;
        else
        cout<<"Skill "<< skillnum <<" is In Active"<<endl;	 			  	  
}

  else if ( choice == 3 )
{  	int skillnum;
  	cout<<"Enter the skill number to be granted: ";
  	cin>> skillnum;
  	
  	if ( skillnum<1 || skillnum>8 )
 {	cout<<"Invalid Skill number"<<endl;
 	return 0;
 }
        unsigned long long mask = 1ULL << ( 16 + ( skillnum - 1 ) );
        warrior = warrior | mask;                                         // TURNING BIT OF SPECIFIC SKILL 'ON'
        cout<<"Skill " << skillnum << " is granted " <<endl;
        cout<<"Skill granted successfully"<<endl; 
        
        if ( skillnum == 1 )
        	defence = defence + 3;
        else if ( skillnum == 2 )
{       	strenght = strenght + 2;  
      	        honor = honor + 2;       }
        else if ( skillnum == 3 )
        	agility = agility + 4;
        else if ( skillnum == 4 )
        	wisdom = wisdom + 3;
        else if ( skillnum == 5 )
        	strenght = strenght + strenght;
        else if ( skillnum == 6 )
        	defence = defence + defence;
        else if ( skillnum == 7 )
        {	agility = agility + 2;		 
         	strenght = strenght + 2;   }
        else 
        	honor = honor + 5;	
        
         skills = ( warrior >> 16 ) & 0xFFULL;
         
        cout<<"\n----Updated Attributes----\n";
	cout<<"Level: "<< int (level) << endl;
	cout<<"Gold: "<< int (gold) << endl;               // 1(ULL) IS USED TO COUNTER UNSIGNED LONG LONG 
	
	cout << "\nSkill Status:" << endl;
	cout << "\tIron Shield: " << ((skills >> 0) & 1ULL) << endl;
	cout << "\tBattle Cry: " << ((skills >> 1) & 1ULL) << endl;
	cout << "\tSwift Step : " << ((skills >> 2) & 1ULL) << endl;
	cout << "\tHealing Aura: " << ((skills >> 3) & 1ULL) << endl;       // TO SHOW WHICH SKILL IS GRANTED
	cout << "\tDragon's Wrath: " << ((skills >> 4) & 1ULL) << endl;
	cout << "\tGuardian's Will: " << ((skills >> 5) & 1ULL) << endl;
	cout << "\tShadow Step: " << ((skills >> 6) & 1ULL) << endl;
	cout << "\tCrown of Valor: " << ((skills >> 7) & 1ULL) << endl;
	
        cout<<"Wisdom: "<< int (wisdom) << endl;       
        cout<<"Strenght: "<< int (strenght) << endl;
        cout<<"Defence: "<< int (defence) << endl;
        cout<<"Agility: "<< int (agility) << endl;
        cout<<"Honor: "<< int (honor) << endl;
        
}  	 
  
  else if ( choice == 4 )
        
{  	int skillnum;
        warrior = ( 0xFFULL << 16 );                                  // SUPPOSE ALL SKILLS ARE ON 
  	cout<<"Enter the skill number to be revoked: ";
  	cin>> skillnum;
  	
  	if ( skillnum<1 || skillnum>8 )
 {	cout<<"Invalid Skill number"<<endl;
 	return 0;
 }
        unsigned long long mask = 1ULL << ( 16 + ( skillnum - 1 ) );
        warrior = warrior & ~mask;                                        // TO TURN OFF THE BIT
        cout<<"Skill " << skillnum << " is revoked " <<endl;
        cout<<"Skill revoked successfully"<<endl; 
        
        if ( skillnum == 1 )
        	defence = defence - 3;
        else if ( skillnum == 2 )
{       	strenght = strenght - 2;  
      	        honor = honor - 2;       }
        else if ( skillnum == 3 )
        	agility = agility - 4;
        else if ( skillnum == 4 )
        	wisdom = wisdom - 3;
        else if ( skillnum == 5 )
        	strenght = strenght - strenght;
        else if ( skillnum == 6 )
        	defence = defence - defence;
        else if ( skillnum == 7 )
        {	agility = agility - 2;		 
         	strenght = strenght - 2;   }
        else 
        	honor = honor - 5;
        
         skills = ( warrior >> 16 ) & 0xFFULL;
         
        cout<<"\n----Updated Attributes-----\n";
	cout<<"Level: "<< int (level) << endl;
	cout<<"Gold: "<< int (gold) << endl;
	
	cout << "\nSkill Status:" << endl;
	cout << "\tIron Shield: " << ((skills >> 0) & 1ULL) << endl;
	cout << "\tBattle Cry: " << ((skills >> 1) & 1ULL) << endl;
	cout << "\tSwift Step : " << ((skills >> 2) & 1ULL) << endl;
	cout << "\tHealing Aura: " << ((skills >> 3) & 1ULL) << endl;       // TO SHOW WHICH SKILL IS GRANTED
	cout << "\tDragon's Wrath: " << ((skills >> 4) & 1ULL) << endl;
	cout << "\tGuardian's Will: " << ((skills >> 5) & 1ULL) << endl;
	cout << "\tShadow Step: " << ((skills >> 6) & 1ULL) << endl;
	cout << "\tCrown of Valor: " << ((skills >> 7) & 1ULL) << endl;
	
        cout<<"Wisdom: "<< int (wisdom) << endl;       
        cout<<"Strenght: "<< int (strenght) << endl;
        cout<<"Defence: "<< int (defence) << endl;
        cout<<"Agility: "<< int (agility) << endl;
        cout<<"Honor: "<< int (honor) << endl;
        
}  	   
  
  else if ( choice == 5 )
{  	int achoice;
  	cout<<"1.Wisdom\n2.Strenght\n3.Defence\n4.Agility\n5.Honor\n  ";
  	cout<<"Enter the Attribute ( 1 - 8 ) to be increased ( -5 GOLD ): ";
  	cin>> achoice;
  	
        if ( achoice<1 || achoice>5 )  
{	cout<<"Invalid Attribute"<<endl;
	return 0;
}             
  	gold = gold - 5;
  	
  	if ( achoice == 1 )
  		wisdom == wisdom + 1;
  	else if ( achoice == 2 )
  		strenght = strenght + 1;
  	else if ( achoice == 3 )
  		defence = defence + 1;
  	else if ( achoice == 4 )
  		agility = agility + 1;
  	else
  		honor = honor + 1;
  		
  	cout<<"\n----Updated Attributes----\n";
	cout<<"Level: "<< int (level) << endl;
	cout<<"Gold: "<< int (gold) << endl;
	
	cout << "\nSkill Status:" << endl;
	cout << "\tIron Shield: " << ((skills >> 0) & 1ULL) << endl;
	cout << "\tBattle Cry: " << ((skills >> 1) & 1ULL) << endl;
	cout << "\tSwift Step : " << ((skills >> 2) & 1ULL) << endl;
	cout << "\tHealing Aura: " << ((skills >> 3) & 1ULL) << endl;       // TO SHOW WHICH SKILL IS GRANTED
	cout << "\tDragon's Wrath: " << ((skills >> 4) & 1ULL) << endl;
	cout << "\tGuardian's Will: " << ((skills >> 5) & 1ULL) << endl;
	cout << "\tShadow Step: " << ((skills >> 6) & 1ULL) << endl;
	cout << "\tCrown of Valor: " << ((skills >> 7) & 1ULL) << endl;
	
        cout<<"Wisdom: "<< int (wisdom) << endl;       
        cout<<"Strenght: "<< int (strenght) << endl;
        cout<<"Defence: "<< int (defence) << endl;
        cout<<"Agility: "<< int (agility) << endl;
        cout<<"Honor: "<< int (honor) << endl;	
  		
}  	
  
   else if ( choice == 6 )
{       level = level + 1;
       
      cout<<"Your Level has increased"<<endl;
      
        if ((skills & 1) == 0) 
        	skills = skills | 1; 
        	           
	else if ((skills & 2) == 0)
	 	skills = skills | 2; 
	 	    
	else if ((skills & 4) == 0) 
		skills = skills | 4; 
		    
	else if ((skills & 8) == 0) 
		skills = skills | 8;                 // CHECKING THE BIT INFRONT OF THE ONE LAST ON BIT
		    
	else if ((skills & 16) == 0)
	 	skills = skills | 16; 
	 	  
	else if ((skills & 32) == 0)
	 	skills = skills | 32;  
	 	 
	else if ((skills & 64) == 0) 
		skills = skills | 64; 
		 
	else if ((skills & 128) == 0)
		 skills = skills | 128;
  	
  	
  	
  	cout<<"\n----Updated Attributes----\n";
	cout<<"Level: "<< int (level) << endl;
	cout<<"Gold: "<< int (gold) << endl;
	
	cout << "\nSkill Status:" << endl;
	cout << "\tIron Shield: " << ((skills >> 0) & 1ULL) << endl;
	cout << "\tBattle Cry: " << ((skills >> 1) & 1ULL) << endl;
	cout << "\tSwift Step : " << ((skills >> 2) & 1ULL) << endl;
	cout << "\tHealing Aura: " << ((skills >> 3) & 1ULL) << endl;       // TO SHOW WHICH SKILL IS GRANTED
	cout << "\tDragon's Wrath: " << ((skills >> 4) & 1ULL) << endl;
	cout << "\tGuardian's Will: " << ((skills >> 5) & 1ULL) << endl;
	cout << "\tShadow Step: " << ((skills >> 6) & 1ULL) << endl;
	cout << "\tCrown of Valor: " << ((skills >> 7) & 1ULL) << endl;
	
        cout<<"Wisdom: "<< int (wisdom) << endl;       
        cout<<"Strenght: "<< int (strenght) << endl;
        cout<<"Defence: "<< int (defence) << endl;
        cout<<"Agility: "<< int (agility) << endl;
        cout<<"Honor: "<< int (honor) << endl;	
  		
}  	
        else if ( choice == 0 )
        return 0;
  	
 
 
 
return 0;
}
