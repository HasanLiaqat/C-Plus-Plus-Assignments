#include <iostream>
using namespace std;
int main()
{
  int num;
  
  cout <<"Enter 3 digit number: ";
  cin >> num;
  
  if ( num<=99 || num >999 )
  { 
  cout <<"Enter valid 3 digit number!"<<endl;
  return 0;
  }
  
  int dig1 = num / 100;
  int dig2 = ( num / 10 ) % 10;
  int dig3 =  num % 10;
  
  if ( (dig1+dig2+dig3) % 3 == 0)
  cout <<"Lucky!"<<endl;
  
  else if ( (dig1*dig2*dig3) % 2 == 0 )
  cout <<"Balanced"<<endl;
  
  else if ( dig1 == dig3 )
  cout <<"Mystical"<<endl;
  
  else
  cout<<"Plain number"<<endl;
  
  return 0;
  
  } 
  
  
  
  
  
  
  
  
  
  
  
  
