#include <iostream>
#include <string>
using namespace std;

int main()
{
	string hexInput;
	
	int chk1, chk2, chk3, chk4, chk5, chk6, chk7, chk8;
	chk1 = chk2 = chk3 = chk4 = chk5 = chk6 = chk7 = chk8 = 0;

	cout << "\nEnter Hex value (only 0-9, A-F, a-f allowed): ";
	cin >> hexInput;
	
	if ( hexInput.size() < 8 || hexInput.size() > 64 )
{	cout<<"Invalid Input!"<<endl;
}	return 0;

	char h1 = hexInput[0];
	char h2 = hexInput[1];
	char h3 = hexInput[2];
	char h4 = hexInput[3];
	char h5 = hexInput[4];
	char h6 = hexInput[5];
	char h7 = hexInput[6];
	char h8 = hexInput[7];
	
	int val1 = 
		(hexInput[0] == '0') ? 0b0000 :
		(hexInput[0] == '1') ? 0b0001 :
		(hexInput[0] == '2') ? 0b0010 :
		(hexInput[0] == '3') ? 0b0011 :
		(hexInput[0] == '4') ? 0b0100 :
		(hexInput[0] == '5') ? 0b0101 :
		(hexInput[0] == '6') ? 0b0110 :                // USING NESTED TERENARY TO FIND BINARY 
		(hexInput[0] == '7') ? 0b0111 :
		(hexInput[0] == '8') ? 0b1000 :
		(hexInput[0] == '9') ? 0b1001 :
		(hexInput[0] == 'A' || hexInput[0] == 'a') ? 0b1010 :
		(hexInput[0] == 'B' || hexInput[0] == 'b') ? 0b1011 :
		(hexInput[0] == 'C' || hexInput[0] == 'c') ? 0b1100 :
		(hexInput[0] == 'D' || hexInput[0] == 'd') ? 0b1101 :
		(hexInput[0] == 'E' || hexInput[0] == 'e') ? 0b1110 :
		(hexInput[0] == 'F' || hexInput[0] == 'f') ? 0b1111 : -1;

	if (val1 == -1) {
		cout << "Invalid hex digit!" << endl;
	}
	if (val1 == 2 || val1 == 3 || val1 == 5 || val1 == 7 || val1 == 11 || val1 == 13)
		chk1 = 1;

	int val2 =
		(hexInput[1] == '0') ? 0b0000 :
		(hexInput[1] == '1') ? 0b0001 :
		(hexInput[1] == '2') ? 0b0010 :
		(hexInput[1] == '3') ? 0b0011 :
		(hexInput[1] == '4') ? 0b0100 :
		(hexInput[1] == '5') ? 0b0101 :
		(hexInput[1] == '6') ? 0b0110 :
		(hexInput[1] == '7') ? 0b0111 :
		(hexInput[1] == '8') ? 0b1000 :
		(hexInput[1] == '9') ? 0b1001 :
		(hexInput[1] == 'A' || hexInput[1] == 'a') ? 0b1010 :
		(hexInput[1] == 'B' || hexInput[1] == 'b') ? 0b1011 :
		(hexInput[1] == 'C' || hexInput[1] == 'c') ? 0b1100 :
		(hexInput[1] == 'D' || hexInput[1] == 'd') ? 0b1101 :
		(hexInput[1] == 'E' || hexInput[1] == 'e') ? 0b1110 :
		(hexInput[1] == 'F' || hexInput[1] == 'f') ? 0b1111 : -1;

	if (val2 == -1) {
		cout << "Invalid hex digit!" << endl;
	}
	if (val2 == 2 || val2 == 3 || val2 == 5 || val2 == 7 || val2 == 11 || val2 == 13)
		chk2 = 1;

	int val3 =
		(hexInput[2] == '0') ? 0b0000 :
		(hexInput[2] == '1') ? 0b0001 :
		(hexInput[2] == '2') ? 0b0010 :
		(hexInput[2] == '3') ? 0b0011 :
		(hexInput[2] == '4') ? 0b0100 :
		(hexInput[2] == '5') ? 0b0101 :
		(hexInput[2] == '6') ? 0b0110 :
		(hexInput[2] == '7') ? 0b0111 :
		(hexInput[2] == '8') ? 0b1000 :
		(hexInput[2] == '9') ? 0b1001 :
		(hexInput[2] == 'A' || hexInput[2] == 'a') ? 0b1010 :
		(hexInput[2] == 'B' || hexInput[2] == 'b') ? 0b1011 :
		(hexInput[2] == 'C' || hexInput[2] == 'c') ? 0b1100 :
		(hexInput[2] == 'D' || hexInput[2] == 'd') ? 0b1101 :
		(hexInput[2] == 'E' || hexInput[2] == 'e') ? 0b1110 :
		(hexInput[2] == 'F' || hexInput[2] == 'f') ? 0b1111 : -1;

	if (val3 == -1) {
		cout << "Invalid hex digit!" << endl;
	}
	if (val3 == 2 || val3 == 3 || val3 == 5 || val3 == 7 || val3 == 11 || val3 == 13)
		chk3 = 1;

	int val4 =
		(hexInput[3] == '0') ? 0b0000 :
		(hexInput[3] == '1') ? 0b0001 :
		(hexInput[3] == '2') ? 0b0010 :
		(hexInput[3] == '3') ? 0b0011 :
		(hexInput[3] == '4') ? 0b0100 :
		(hexInput[3] == '5') ? 0b0101 :
		(hexInput[3] == '6') ? 0b0110 :
		(hexInput[3] == '7') ? 0b0111 :
		(hexInput[3] == '8') ? 0b1000 :
		(hexInput[3] == '9') ? 0b1001 :
		(hexInput[3] == 'A' || hexInput[3] == 'a') ? 0b1010 :
		(hexInput[3] == 'B' || hexInput[3] == 'b') ? 0b1011 :
		(hexInput[3] == 'C' || hexInput[3] == 'c') ? 0b1100 :
		(hexInput[3] == 'D' || hexInput[3] == 'd') ? 0b1101 :
		(hexInput[3] == 'E' || hexInput[3] == 'e') ? 0b1110 :
		(hexInput[3] == 'F' || hexInput[3] == 'f') ? 0b1111 : -1;

	if (val4 == -1) {
		cout << "Invalid hex digit!" << endl;
	}
	if (val4 == 2 || val4 == 3 || val4 == 5 || val4 == 7 || val4 == 11 || val4 == 13)
		chk4 = 1;

	int val5 =
		(hexInput[4] == '0') ? 0b0000 :
		(hexInput[4] == '1') ? 0b0001 :
		(hexInput[4] == '2') ? 0b0010 :
		(hexInput[4] == '3') ? 0b0011 :
		(hexInput[4] == '4') ? 0b0100 :
		(hexInput[4] == '5') ? 0b0101 :
		(hexInput[4] == '6') ? 0b0110 :
		(hexInput[4] == '7') ? 0b0111 :
		(hexInput[4] == '8') ? 0b1000 :
		(hexInput[4] == '9') ? 0b1001 :
		(hexInput[4] == 'A' || hexInput[4] == 'a') ? 0b1010 :
		(hexInput[4] == 'B' || hexInput[4] == 'b') ? 0b1011 :
		(hexInput[4] == 'C' || hexInput[4] == 'c') ? 0b1100 :
		(hexInput[4] == 'D' || hexInput[4] == 'd') ? 0b1101 :
		(hexInput[4] == 'E' || hexInput[4] == 'e') ? 0b1110 :
		(hexInput[4] == 'F' || hexInput[4] == 'f') ? 0b1111 : -1;

	if (val5 == -1) {
		cout << "Invalid hex digit!" << endl;
	}
	if (val5 == 2 || val5 == 3 || val5 == 5 || val5 == 7 || val5 == 11 || val5 == 13)
		chk5 = 1;

	int val6 =
		(hexInput[5] == '0') ? 0b0000 :
		(hexInput[5] == '1') ? 0b0001 :
		(hexInput[5] == '2') ? 0b0010 :
		(hexInput[5] == '3') ? 0b0011 :
		(hexInput[5] == '4') ? 0b0100 :
		(hexInput[5] == '5') ? 0b0101 :
		(hexInput[5] == '6') ? 0b0110 :
		(hexInput[5] == '7') ? 0b0111 :
		(hexInput[5] == '8') ? 0b1000 :
		(hexInput[5] == '9') ? 0b1001 :
		(hexInput[5] == 'A' || hexInput[5] == 'a') ? 0b1010 :
		(hexInput[5] == 'B' || hexInput[5] == 'b') ? 0b1011 :
		(hexInput[5] == 'C' || hexInput[5] == 'c') ? 0b1100 :
		(hexInput[5] == 'D' || hexInput[5] == 'd') ? 0b1101 :
		(hexInput[5] == 'E' || hexInput[5] == 'e') ? 0b1110 :
		(hexInput[5] == 'F' || hexInput[5] == 'f') ? 0b1111 : -1;

	if (val6 == -1) {
		cout << "Invalid hex digit!" << endl;
	}
	if (val6 == 2 || val6 == 3 || val6 == 5 || val6 == 7 || val6 == 11 || val6 == 13)
		chk6 = 1;

	int val7 =
		(hexInput[6] == '0') ? 0b0000 :
		(hexInput[6] == '1') ? 0b0001 :
		(hexInput[6] == '2') ? 0b0010 :
		(hexInput[6] == '3') ? 0b0011 :
		(hexInput[6] == '4') ? 0b0100 :
		(hexInput[6] == '5') ? 0b0101 :
		(hexInput[6] == '6') ? 0b0110 :
		(hexInput[6] == '7') ? 0b0111 :
		(hexInput[6] == '8') ? 0b1000 :
		(hexInput[6] == '9') ? 0b1001 :
		(hexInput[6] == 'A' || hexInput[6] == 'a') ? 0b1010 :
		(hexInput[6] == 'B' || hexInput[6] == 'b') ? 0b1011 :
		(hexInput[6] == 'C' || hexInput[6] == 'c') ? 0b1100 :
		(hexInput[6] == 'D' || hexInput[6] == 'd') ? 0b1101 :
		(hexInput[6] == 'E' || hexInput[6] == 'e') ? 0b1110 :
		(hexInput[6] == 'F' || hexInput[6] == 'f') ? 0b1111 : -1;

	if (val7 == -1) {
		cout << "Invalid hex digit!" << endl;
	}
	if (val7 == 2 || val7 == 3 || val7 == 5 || val7 == 7 || val7 == 11 || val7 == 13)
		chk7 = 1;

	int val8 =
		(hexInput[7] == '0') ? 0b0000 :
		(hexInput[7] == '1') ? 0b0001 :
		(hexInput[7] == '2') ? 0b0010 :
		(hexInput[7] == '3') ? 0b0011 :
		(hexInput[7] == '4') ? 0b0100 :
		(hexInput[7] == '5') ? 0b0101 :
		(hexInput[7] == '6') ? 0b0110 :
		(hexInput[7] == '7') ? 0b0111 :
		(hexInput[7] == '8') ? 0b1000 :
		(hexInput[7] == '9') ? 0b1001 :
		(hexInput[7] == 'A' || hexInput[7] == 'a') ? 0b1010 :
		(hexInput[7] == 'B' || hexInput[7] == 'b') ? 0b1011 :
		(hexInput[7] == 'C' || hexInput[7] == 'c') ? 0b1100 :
		(hexInput[7] == 'D' || hexInput[7] == 'd') ? 0b1101 :
		(hexInput[7] == 'E' || hexInput[7] == 'e') ? 0b1110 :
		(hexInput[7] == 'F' || hexInput[7] == 'f') ? 0b1111 : -1;

	if (val8 == -1) {
		cout << "Invalid hex digit!" << endl;
	}
	if (val8 == 2 || val8 == 3 || val8 == 5 || val8 == 7 || val8 == 11 || val8 == 13)
		chk8 = 1;

	if (chk1 == 1) {
		cout << "\nSecurity risk found at bits 0–3 : " << h1 << endl;
		cout << "Key Security compromised - Prime Detected\n";
	}
	if (chk2 == 1) {
		cout << "\nSecurity risk found at bits 4–7 : " << h2 << endl;
		cout << "Key Security compromised - Prime Detected\n";
	}
	if (chk3 == 1) {
		cout << "\nSecurity risk found at bits 8–11 : " << h3 << endl;
		cout << "Key Security compromised - Prime Detected\n";
	}
	if (chk4 == 1) {
		cout << "\nSecurity risk found at bits 12–15 : " << h4 << endl;
		cout << "Key Security compromised - Prime Detected\n";
	}
	if (chk5 == 1) {
		cout << "\nSecurity risk found at bits 16–19 : " << h5 << endl;
		cout << "Key Security compromised - Prime Detected\n";
	}
	if (chk6 == 1) {
		cout << "\nSecurity risk found at bits 20–23 : " << h6 << endl;
		cout << "Key Security compromised - Prime Detected\n";
	}
	if (chk7 == 1) {
		cout << "\nSecurity risk found at bits 24–27 : " << h7 << endl;
		cout << "Key Security compromised - Prime Detected\n";
	}
	if (chk8 == 1) {
		cout << "\nSecurity risk found at bits 28–31 : " << h8 << endl;
		cout << "Key Security compromised - Prime Detected\n";
	}

	if (chk1 == 0 && chk2 == 0 && chk3 == 0 && chk4 == 0 && chk5 == 0 && chk6 == 0 && chk7 == 0 && chk8 == 0) {
		cout << "\nKey validated successfully - No prime bit patterns detected.\n";
		cout << "Key Security is Safe\n";
	}

	return 0;
}



