#include<iostream>
using namespace std;
#include<string>
int main()
{
  int age;
	  cout << "Enter your age: ";
	  cin >> age;
	  
	  if ( age < 0 )
	 {
	  cout<<"Invalid Age"<<endl;
	  return 0;
	 } 
	  
  string boole;
	  cout<<"Are you a student?\nyes or no: ";
	  cin>> boole;
	  
  if ( age < 5 )
    	cout<<"Ticket Price = Free"<<endl;
  else if ( age>=5 && age<=12 )
              {	
  		if ( boole == "yes" ) 
  			cout<<"Ticket Price = 240 PKR"<<endl;
  		else
  			cout<<"Ticket Price = 300 PKR"<<endl;
               }
  else if ( age>=13 && age<=18 )
               {	
  		if ( boole == "yes" ) 
  			cout<<"Ticket Price = 400 PKR"<<endl;
  		else
  			cout<<"Ticket Price = 500 PKR"<<endl;
               }	  	  
  else 
               {
      		if ( boole == "yes" ) 
  			cout<<"Ticket Price = 800 PKR"<<endl;
  		else
  			cout<<"Ticket Price = 1000 PKR"<<endl;   
                }
       	       
  
  
  return 0;
  
  }
  
  
