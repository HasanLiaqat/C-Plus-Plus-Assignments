#include <iostream>
using namespace std;
int main()
{
    unsigned long long packet;
    cout<<"Enter 64 Bit integer as a packet: ";
   
    
   if ( !(cin>> packet) )
{   cout<<"Invalid Input!"<<endl;
    return 0;  }  
    
    
    unsigned long long tdata = packet & ( ( 1ULL << 48 ) - 1 );
    unsigned long long checksum = ( packet >> 48 ) & 0xFFULL;       
    unsigned long long tag = ( packet >> 56 ) & 0x7FULL;          
    unsigned long long parity = ( packet >> 63 ) & 1 ;

    cout<<"\n------------------------\n"<<endl;
    cout<<"CheckSum: "<<checksum<<endl;
    cout<<"Crypto Graphic Tag: "<<tag<<endl;
    cout<<"Parity: "<<parity<<endl;
    cout<<"Threat Data: "<<tdata<<endl;
    
    cout<<"\n-----ERROR DETECTION-----\n"<<endl;
    
    int a=0;
    int count=0;
    
    while ( a < 48 )
{	if ( (tdata >> a) & 1 )
	   count = count + 1;             // COUNTING NO OF 1 IN THREAT DATA
	   a = a + 1;
}	 
    int eparity;
	    if ( count & 1  )
	    eparity = 0;
	    else                        // CHECKING IF NO OF 1s IS EVEN OR ODD
	    eparity = 1;
	    
     if ( eparity == parity )
     cout<<"\nNo Parity Error"<<endl;
     else
     cout<<"\nPacket is Corrupted\nParity Error Detected"<<endl;
     
     
     
     unsigned long long lower = tdata & ( (1ULL << 24) - 1 );               // APPLY MASK TO EXTRACT LOWER 24 BITS
     unsigned long long upper = (tdata >> 24) & ( (1ULL << 24) - 1 );       // FIRST RIGHT SHIFT UPPER 24 BITS THEN APPLY MASK 
     
     unsigned long long bxor = upper ^ lower;
     unsigned long long rshift = bxor >> 2;
     unsigned long long last8 = rshift & 0xFF;     // EXTRACTING LAST 8 BITS
     
     if ( last8 == checksum )
        cout<<"\nNo CheckSum Error"<<endl;
        else
        cout<<"\nPacket is Corrupted\nCheckSum Error Detected"<<endl;
        
        
        unsigned long long toggledata = (~tdata) & 0xFFFFFFFFFFFF;   // FLIPPING ALL BITS OF THREAT DATA ( 48 BITS )
        unsigned long long key = 0;
        
        // TRANSVERSE FROM LEFT TO RIGHT
        
        for ( int i = 47; i > 0 ; i--)
{	unsigned long long bit1 = ( toggledata >> i ) & 1ULL;             // CURRENT BIT
	unsigned long long bit2 = ( toggledata >> (i-1) ) & 1ULL;        // NEXT BIT        
        
              if ( bit1 == bit2 )
{        	key = key + 1;   // INCREMENT TO KEY
        	key = key << 1;  // MULTIPLY BY 2
}   
}
	key = key & 0x7FULL;    // EXTRACTING LAST 7 BITS
	key = key ^ 0x7FULL;   // INVERTING AGAIN LAST 7 BITS 	
	
	if ( key == tag )
	cout<<"\nNo Health Key Error"<<endl;
	else
	cout<<"\nPacket is Corrupted\nHealth Key Error Detected"<<endl; 
	
	
	
	if ( (( tdata & 0x1F ) != 0) && (( tdata & 0x3) == 1 ) )  
    	 cout<<"\nYour Threat Data is Cyber Prime"<<endl;
       else
	cout<<"\nYour Threat Data is not Cyber Prime\nPacket is Corrupted\n"<<endl; 
    
 return 0;   
}
 
