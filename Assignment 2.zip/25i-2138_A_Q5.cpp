#include<iostream>
using namespace std;
int main()
{
  char spoint;
  
  cout<<"Enter the starting point: ";
  cin>> spoint;
  
  if ( (spoint=='L') || (spoint=='M') || (spoint=='N') || (spoint=='O') || (spoint=='P') )
 {  
  switch ( spoint )
{
  case 'L':
  	cout<<"You will visit A round about"<<endl;     
  case 'M':
  	cout<<"You will visit B round about"<<endl;
  case 'N':
  	cout<<"You will visit C round about"<<endl;
  case 'O':
  	cout<<"You will visit D round about"<<endl;
  case 'P':
  	cout<<"You will visit E round about"<<endl;
  	
  }	
  
  if ( spoint == 'L' )
  cout<<"Total distance covered: 12 KM"<<endl;
  else if ( spoint == 'M' )
  cout<<"Total distance covered: 8 KM"<<endl;
  else if ( spoint == 'N' )
  cout<<"Total distance covered: 6 KM"<<endl;
  else if ( spoint == 'O' )
  cout<<"Total distance covered: 3 KM"<<endl;
  else if ( spoint == 'P' )
  cout<<"Total distance covered: 2 KM"<<endl;
}

   else 
   cout<<"Invalid Starting Point"<<endl;
  

   cout<<"\n";
  
  			
    return 0;
    
    }
