#include<iostream>
#include<string>
using namespace std;
int main()
{
  int slevel;
  string cattack,dtype;
  
  cout<<"\nInput the Attack Type: ";
  getline ( cin, cattack );                     // SO THAT INPUT CAN HAVE SPACES 
   
  cout<<"\nEnter the severity level ( 1-5 ): ";
  cin>> slevel;
  cin.ignore();                                 // CLEARS LEFTOVER GARBAGE
   
   if ( slevel<1 || slevel>5)
  {
   cout<<"\nInvalid severity level"<<endl;   // VALIDATION OF SEVERITY LEVEL
   return 0;
  } 
   
   cout<<"\nInput the data type ( Personal,Financial,Healthcare,Intellectual Property,Corporate Secrets,User Credentials ): ";
   getline ( cin, dtype );
   
   int acode=-5;
   
   if ( cattack == "DDoS" )
   acode=1;
   else if ( cattack == "Phishing" )
   acode=2;
   else if ( cattack == "Malware" )
   acode=3;
   else if ( cattack == "SQL Injection" )
   acode=4;
   else if ( cattack == "Ransomware" )
   acode=5;
   else if ( cattack == "Cross-Site Scripting" )
   acode=6;
   else if ( cattack == "Man-in-the-Middle" )
   acode=7;
   else if ( cattack == "Credential Stuffing" )
   acode=8;
   else if ( cattack == "Zero-Day Exploit" )
   acode=9;
   else if ( cattack == "Insider Threat" )
   acode=10;
   
   if ( acode == -5 )
 {  cout<<"Invalid Attack Type!"<<endl;           // VALIDATING THE ATTACK TYPE
   return 0;  }
   
   switch ( acode )
 {
   case 1:
   	if ( slevel==4 || slevel==5 )
   	cout<<"Critical Network Threat"<<endl;
   	else
   	cout<<"Unknown ThreatLevel"<<endl;
   	break;
   	
   case 2:
   	if ( dtype == "Finanacial" )
   	cout<<"High Risk of Fraud"<<endl;
   	else
   	cout<<"Unknown ThreatLevel"<<endl;
   	break;
   	
   case 3:
   	if ( slevel>=3 )
   	cout<<"Potential Data Breach"<<endl;
   	else
   	cout<<"Unknown ThreatLevel"<<endl;
   	break;
   	
   case 4:
   	if ( slevel==4 || slevel==5 )
   	cout<<"Data base Compromise"<<endl;
   	else
   	cout<<"Unknown ThreatLevel"<<endl;
   	break;
   	
   case 5:
   	cout<<"Critical Threat to Data Integrity"<<endl;
   	break;
   	
   case 6:
   	if ( slevel>=3 )
   	cout<<"Web Application Vulnerability"<<endl;
   	else
   	cout<<"Unknown ThreatLevel"<<endl;
   	break;
   	
   case 7:
   	if ( dtype == "User Credentials" )
   	cout<<"Critical Credential Theft"<<endl;
   	else
   	cout<<"Unknown ThreatLevel"<<endl;
   	break;
   	
   case 8:
   	if ( slevel==4 || slevel==5 )
   	cout<<"Severe Account Takeover Risk"<<endl;
   	else
   	cout<<"Unknown ThreatLevel"<<endl;
   	break;
   	
   case 9:
   	cout<<"Immediate Patch Required"<<endl;   	
   	break;
   	
   case 10:
        if ( slevel == 5 )
   	cout<<"Critical Internal Breach"<<endl;
   	else
   	cout<<"Unknown ThreatLevel"<<endl;
   	break;
   	
   default:
   	cout<<"Unknown Threat Level"<<endl;
   	
  } 			
   									  
   cout<<"\n";
  
  return 0;
  
  }
  
  
  
  
  
