#include<iostream>
#include<string>
using namespace std;
int main()
{
  int attempt,packetsize;
  string sourceip,destip,protocol; 
 
  cout<<"\nEnter the Source IP Address ( ?.?.? ): ";
  cin>> sourceip;
  
  cout<<"\nEnter the Destination IP Address ( ?.?.?.? ): ";
  cin>> destip;
  
  cout<<"\nEnter the Packet Size ( in bytes ): ";
  cin>> packetsize;
  
  cout<<"\nEnter the Protocol ( HTTP, HTTPS, FTP, SSH, DNS, SMTP ): ";
  cin>> protocol;
  
  cout<<"\nEnter the number of Failed Login Attempts: ";
  cin>> attempt;
  
  if ( attempt > 5 )
  cout <<"\nHighly Malicious"<<endl;
  
  else if ( (packetsize > 10000) && (protocol == "HTTP") )
  cout <<"\nHighly Malicious"<<endl;
  
  else if ( sourceip.find("192.168.0.") == 0 || sourceip.find("10.0.") == 0 )
  cout <<"\nHighly Malicious"<<endl;
  
  else if ( (protocol == "FTP" || protocol == "SSH") && (packetsize > 5000) )
  cout <<"\nPotentially Malicious"<<endl; 
  
  else if ( (protocol == "DNS") && ( (destip == "8.8.8.8") || (destip == "8.8.4.4") ) )
  cout <<"\nPotentially Malicious"<<endl; 
  
  else if ( attempt>=3 && attempt<=5 )
  cout <<"\nPotentially Malicious"<<endl; 
  
  else 
  cout<<"\nSAFE"<<endl; 
  
  cout<<"\n";
  return 0;
  
  
  
  }
  
