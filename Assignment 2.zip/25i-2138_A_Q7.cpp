#include<iostream>
#include<string>
using namespace std;
  int main()
{
    unsigned long long packet;
    cout<<"Enter 64 Bit integer as a packet: ";
    
    if ( !(cin>> packet) )
{   cout<<"Invalid Input!"<<endl;
    return 0;  }
    
    
    unsigned long long mdata = packet & ( ( 1ULL << 48 ) - 1 );
    unsigned long long checksum = ( packet >> 48 ) & 0xFFULL;       // 0xFF = 8 BITS ( 11111111 )
    unsigned long long hkey = ( packet >> 56 ) & 0x7FULL;          // 0x7F = 7 BITS ( 01111111 )
    unsigned long long parity = ( packet >> 63 ) & 1 ;
    
    cout<<"\n------------------------\n"<<endl;
    cout<<"CheckSum: "<<checksum<<endl;
    cout<<"Health Key: "<<hkey<<endl;
    cout<<"Parity: "<<parity<<endl;
    
    
    cout<<"\n-----ERROR DETECTION-----\n"<<endl;
    
     
    if ( ( mdata & 0x1F ) == 0 )  
     cout<<"\nYour Medical Data is not Vital Prime\nPacket is Corrupted\n"<<endl;
   else
    cout<<"\nYour Medical Data is Vital Prime"<<endl;
    
    
    int a=0;
    int count=0;
    
    while ( a < 48 )
{	if ( (mdata >> a) & 1 )
	   count = count + 1;             // COUNTING NO OF 1 IN MEDICAL DATA
	   a = a + 1;
}	 
    int eparity;
	    if ( count & 1 )
	    eparity = 0;
	    else                        // CHECKING IF NO OF 1s IS EVEN OR ODD
	    eparity = 1;
	    
     if ( eparity == parity )
     cout<<"\nNo Parity Error"<<endl;
     else
     cout<<"\nPacket is Corrupted\nParity Error Detected"<<endl;
     
    					 //SPLITTING INTO EVEN AND ODD BIT GROUPS
     unsigned long long evenbit=0;
     unsigned long long oddbit=0;
     int even=0;
     int odd=0;
     
     for ( int b=0;b<48;b++ )
{	unsigned long long bit = ( mdata >> b ) & 1ULL;

	if ( (b & 1ULL) == 0 )  // CHECKS LOWEST BIT OF b if 1=odd 0=even
{	evenbit = evenbit | (bit << even);          // EVEN GROUP
	even = even + 1;
}
	else
{	oddbit = oddbit | (bit << odd);            // ODD GROUP
	odd = odd + 1;		
}
}
        unsigned long long combined = evenbit ^ oddbit;    // USED XOR TO CLEAR OUT ALL 1s ( IF BOTH BITS ARE 1 ) 
        unsigned long long divide = combined >> 1;         // >> means divided by 2^n :: here n is 1
        unsigned long long echecksum = divide & 0xFF;     // MOVING THIS TO RIGHT MOST 8 BITS AND EXTRACTING
        
        if ( echecksum == checksum )
        cout<<"\nNo CheckSum Error"<<endl;
        else
        cout<<"\nPacket is Corrupted\nCheckSum Error Detected"<<endl;
        
        
        unsigned long long toggledata = (~mdata) & 0xFFFFFFFFFFFF;   // FLIPPING ALL BITS OF MEDICAL DATA ( 48 BITS )
        unsigned long long key = 0;
        
        int c=0;
        
        while ( c < 46 )                                        // SO THAT IT DONT EXCEED 48 BITS
{	unsigned long long bit1 = ( toggledata >> c ) & 1;      // CURRENT BIT
	unsigned long long bit2 = ( toggledata >> (c+2) ) & 1;    // ALTERNATE BIT    
     
        if ( bit1 == bit2 )
{        	key = key + 1;   // INCREMENT TO KEY
        	key = key << 2;  // MULTIPLY BY 2
}   
	c = c+1;
}
	key = key & 0x7FULL;    // EXTRACTING LAST 7 BITS
	key = key ^ 0x7FULL;   // TOGGLING LAST 7 BITS 	
	
	if ( key == hkey )
	cout<<"\nNo Health Key Error"<<endl;
	else
	cout<<"\nPacket is Corrupted\nHealth Key Error Detected"<<endl;    
       
    
  return 0;
  
  }
