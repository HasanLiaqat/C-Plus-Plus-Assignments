#include <iostream>
#include <string>
using namespace std;
int main()
{	
	int s1,s2,temp;
	
	cout<<"Enter size of Array 1: ";
	cin>>s1;
	
	int arr1[s1];
	
	cout<<"Enter Integers in Array 1: ";
	for (int i=0 ; i<s1 ; i++)
	{
		cin>>arr1[i];
	} 
	
	cout<<"Enter size of Array 2: ";
	cin>>s2;
	
	int arr2[s2];
	
	cout<<"Enter Integers in Array 2: ";
	for (int i=0 ; i<s2 ; i++)
	{
		cin>>arr2[i];
	} 
	
	if ( s1 != s2 )
	{
		cout<<"\nFalse, Both arrays are not equal"<<endl;
		return 0;
	}
	
	for (int i=0 ; i<s1 ; i++)
	{
		for (int j=i+1; j<s1 ; j++)
		{
			if ( arr1[i] > arr1[j] )
			{
				temp = arr1[i];
				arr1[i] = arr1[j];
				arr1[j] = temp;	
			}
		}
	}
	
	for (int i=0 ; i<s2 ; i++)
	{
		for (int j=i+1; j<s2 ; j++)
		{
			if ( arr2[i] > arr2[j] )
			{
				temp = arr2[i];
				arr2[i] = arr2[j];
				arr2[j] = temp;	
			}
		}
	}
	
	bool same = false;
	for ( int i=0 ; i<s1 ; i++ )
	{
		if ( arr1[i] == arr2[i] )
		{
			same = true;
		}
		
		else 
		{
			cout<<"\nFalse, Both arrays are not equal"<<endl;
			return 0;
		}
	}
	
	if ( same )
	cout<<"\nTrue, Both Arrays have same elements"<<endl;
	
	return 0;
}



