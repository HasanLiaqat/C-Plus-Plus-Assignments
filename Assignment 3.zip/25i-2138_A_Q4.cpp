#include <iostream>
using namespace std;
int main() 
{
    long long bin;
    int deci = 0;
    int base = 1; 
   
    cout << "Enter a binary number: ";
    cin >> bin;
    
    if (bin < 0)
    {
    	cout << "Invalid Input!" <<endl;
        return 0;
    }
   
    for (long long n = bin; n>0; n=n/10) 
    {
        int digit = n%10;
       
        if (digit == 1) 
        {
            deci = deci + base;
        } 
        
        else if (digit != 0) 
        {
            cout << "Error, Invalid binary digit!" <<endl;
            return 0;
        }
       
        base = base*2;
    }
   
    cout << "Decimal: "<< deci <<endl;
   
    return 0;
}
  
  
  
  
  
