#include<iostream>
using namespace std;
int main()
{
	int a;
	
	cout<<"Enter number of letters in word: ";
	cin>>a;
	
	if ( a>10 )
	{
		cout<<"Invalid! Only 10 letter words allowed"<<endl;
		return 0;
	}
	
	char arr1[11];
	char arr2[11];
	
	cout<<"Enter original word ( only CAPITAL )"<<endl;
	for (int i=0; i<a ; i++)
	{
		cin>>arr1[i];
	}
	
	cout<<"Enter contestant word ( only CAPITAL )"<<endl;
	for (int i=0; i<a ; i++)
	{
		cin>>arr2[i];
	}
	
	
	int count = 0;
	for (int i=0; i<a ; i++)
	{
		if ( arr1[i] != arr2[i] )
		{
			count++;
		}
	} 
	
	cout<<"\n";
	
	if ( count == 0)
		cout<<"CORRECT"<<endl;
		
	else if ( count == 1 || count == 2 )
		cout<<"ALMOST CORRECT"<<endl;
		
	else 
		cout<<"WRONG"<<endl;
 
	
   return 0;
}   	
	
	
	
	
	
	
	 
