#include <iostream>
using namespace std;
int main() 
{
    int n;
    bool found = false;

    cout<<"Enter amount in PKR: ";
    cin>>n;
    
    if (n<0)
    {
    	cout<<"Invalid Input!"<<endl;
    	return 0;
    }

    int a = 0;				// MOST OUTER LOOP FOR NOTES OF 6
    
    do 
    {
        int b = 0; 			// MIDDLE LOOP FOR NOTES OF 9
       
        do 
        {
            int c = 0; 			// LAST LOOP FOR NOTES OF 20
 
            do 
            {
                if (6*a + 9*b + 20*c == n) 
                {
                    found = true;
                    cout<<"Yes "<<n<<" PKR. can be exchanged\n\n";
                    cout<< a << " notes of 6\n";
                    cout<< b << " notes of 9\n";
                    cout<< c << " notes of 20"<< endl;
                    break; 
                }
                c++;
            } 
            
            while (6 * a + 9 * b + 20 * c <= n);

            if (found) 
            break; 
            b++;
        } 
        
    	    while (6 * a + 9 * b <= n);

      	    if (found) 
            break; 
            a++;
    }
    
    	 while (6 * a <= n);

    if (!found) 
    {
        cout<<"Not possible to exchange exactly"<<n<<" PKR."<<endl;
    }

    return 0;
}
