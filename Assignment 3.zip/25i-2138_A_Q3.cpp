#include <iostream>
using namespace std;
int main()
{
    int i=0;
    while ( i<9 )
    {
        int sp=0;
        while ( sp <= 8-i )
        {
            cout<<"  ";
            sp++;
        }
        int j=1;
        while ( j <= i+1 )
        {
            cout<<j<<" ";
            j++;
        }
        int k =i;
        while ( k>=1 )
        {
            cout<<k<<" ";
            k--;
        }
       
        cout<<endl;
        i++;
    }
    int z=0;
    while ( z<8 )
    {
        int sp=0;
        while ( sp <= z+1 )
        {
            cout<<"  ";
            sp++;
        }
        int j=1;
        while ( j <= 8-z )
        {
            cout<<j<<" ";
            j++;
        }
       
        cout<<endl;
        z++;
    }
   
   

    return 0;
}

