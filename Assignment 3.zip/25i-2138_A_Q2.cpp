#include <iostream>
using namespace std;

int main() 
{
    int i = 0;
    while (i <= 6) 
    {
        int j = 0;
        while (j < 6 - i) 
        {
            cout << "*";
            j++;
        }

        int sp = 0;
        while (sp <= i) 
        {
            cout << " ";
            sp++;
        }

        int k = 0;
        while (k < 6 - i) 
        {
            cout << "//";
            k++;
        }

        int l = 1;
        while (l <= 2 * i) 
        {
            cout << "\\";
            l++;
        }

        int sp1 = 0;
        while (sp1 <= i)
        {
            cout << " ";
            sp1++;
        }

        int o = 0;
        while (o < 6 - i)  
        {
            cout << "*";
            o++;
        }

        cout << endl;
        i++;
    }

    return 0;
}

