#include <iostream>
using namespace std;
int main()
{
   for (int i=0 ; i<6 ; i++)
   {
       char ch = 'A';
       for(int j=0 ; j<6-i ; j++)
       {
          cout<<ch;
          ch++;
       }
       
       for (int sp=1; sp <= i ; sp++)
       {
           cout<<" ";
       }
       
       for (int sp=1; sp <= i ; sp++)
       {
           cout<<" ";
       }
       
       for (char ch = 'E' - i+1; ch >= 'A'; ch--)
       {
           cout << ch;
       }
       
       
       cout<<endl;
   }

    return 0;
}
