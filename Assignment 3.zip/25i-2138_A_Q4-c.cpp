#include<iostream>
#include<climits>
using namespace std;
int main()
{
	int i=1,j=2;
	int n=1;
	
	while (n<10)			// IT WILL RUN 10 ITERATIONS, DEPENDS UPON USER
	{
		cout<<i<<"/"<<j<<" ";
		i = 2*i+1;
		j = 2*j;
		n++;
	}
	
	
   return 0;
}   	
