#include <iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int main()
{
	int lottery[5];
	int user[5];
	
	srand( time(NULL) );

	
	for ( int i=0 ; i<5 ; i++ )
	{
		lottery[i] = rand() % 10;
	}   
	
	cout<<"Enter 5 Numbers to win lottery (0-9) : "<<endl;
	for ( int j=0 ; j<5 ; j++ )
	{
		cin>>user[j];
		
		while ( user[j] < 0  || user[j] >9 )
		{
			cout<<"Invalid! Numbers should be in between 0 and 9\nEnter Again: ";
			cin>>user[j];	
		} 
	} 
	
	cout<<"\n";
	
	cout<<"Lottery Numbers : ";
	for (int k=0 ; k<5 ; k++)
	{	
		cout<<lottery[k]<<" ";			
	}
	
	cout<<"\n";
	
	cout<<"   User Numbers : ";
	for (int k=0 ; k<5 ; k++)
	{	
		cout<<user[k]<<" ";			
	}
	
	cout<<"\n";
	
  
	int count=0;  	   
	for (int k=0 ; k<5 ; k++)
	{   
		if (lottery[k] == user[k])
		{			
			count++;
		} 	
	}
	
	cout<<"\nNumber of Matching Digits: "<<count<<endl;
	
	if ( count == 5 )
	{
		cout<<"\nCongratulations!"<<endl;
		cout<<"You won the Grand Prize"<<endl;
	}	
	   
 return 0;   
}
 
