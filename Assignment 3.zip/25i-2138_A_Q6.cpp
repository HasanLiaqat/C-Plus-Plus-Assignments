#include <iostream>
using namespace std;
int main()
{
	int arr1[50];
	int arr2[50];
	int n1,n2;
	
	cout<<"Enter the number of integers you want in array1: ";
	cin>>n1;
	
	
	for (int i=0 ; i<n1 ; i++)
	{
		cout<<"Enter integers in array1 in ascending order: ";
		cin>>arr1[i];
	} 
	
	cout<<"\nEnter the number of integers you want in array2: ";
	cin>>n2;	
	
	for (int j=0 ; j<n2 ; j++)
	{
		cout<<"Enter integers in array2 in ascending order: ";
		cin>>arr2[j];
	} 
	
	int arr3[n1+n2];
	
	
	int a=n1-1;
	int b=n2-1;
	int c=0;
	
	while (a>=0 && b>=0)
	{
		if ( arr1[a] > arr2[b] )
		{
			arr3[c] = arr1[a];
			a--;
			c++;	
		}
		
		else
		{
			arr3[c] = arr2[b];
			b--;
			c++;			
		}
	}
	
	while ( a>=0 )
	{
		arr3[c] = arr1[a];
		a--;
		c++;
	}					// ANY ELEMENT REMAINS IN CASE IF ARRAYS ARE NOT EQUAL IN SIZE
	
	while ( b>=0 )
	{
		arr3[c] = arr2[b];
		b--;
		c++;
	}
	
	cout<<"\n";
	cout<<"Merged Array: ";
	
	for ( int o=0 ; o<c ; o++ )
	{
		cout<<arr3[o]<<" ";
	}
	
	cout<<endl;
 
   return 0;
}
