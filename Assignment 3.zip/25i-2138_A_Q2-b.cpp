#include <iostream>
using namespace std;
int main() 
{   
    for ( int i = 0 ; i<6 ; i++)
    {
        for ( int j = 1; j<=2*i ; j++)
        {
            cout<<"\\";
        }
       
        for ( int k=0 ; k<=22-(4*i)-1  ; k++ )
        {
            cout<<"!";
        }
       
        for ( int s=1 ; s<=i  ; s++ )
        {
            cout<<"//";
        }
       
        cout<<endl;
    }

    return 0;
}























