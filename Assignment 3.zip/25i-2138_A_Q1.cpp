#include<iostream>
using namespace std;
int main()
{
	for ( int i =0 ; i < 6 ; i++ )
	{
		cout<<"#";                         // HASHTAG
		
		for ( int j =0; j < i ; j++ )
		{				   // SPACES
			cout<<" ";
		}
		
		cout<<"#";			// HASHTAG
		
		
		cout<<endl;
	}

  	  
  return 0;
  
  }
  
  
