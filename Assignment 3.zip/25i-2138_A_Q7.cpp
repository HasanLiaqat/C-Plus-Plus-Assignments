#include<iostream>
#include<string>
using namespace std;
  int main()
{
	long empid[7] = { 5658845, 4520125, 7895122, 8777541, 8451277, 1302850, 7580489};
	int hours[7];
	double payrate[7];
	double wages[7];
	
	for (int i=0 ; i<7 ; i++)
	{
		cout<<"Enter hours worked by Employee ID "<<empid[i]<<" : ";
		cin>>hours[i];
		
		while ( hours[i] < 0 )
		{
			cout<<"Invalid! Hours can't be negative\nEnter Again: ";
			cin>>hours[i];	
		}
		
		cout<<"Enter Pay Rate for Employee ID "<<empid[i]<<" : ";
		cin>>payrate[i];
		cout<<endl;
		
		while ( payrate[i] < 6 )
		{
			cout<<"Invalid! Pay Rate can't be less than 6\nEnter Again: ";
			cin>>payrate[i];	
		}
		
		wages[i] = hours[i] * payrate[i];
	}
	
	for (int j=0 ; j<7 ; j++)
	{
		cout<<"Gross Wage for Employee ID "<<empid[j]<<" is : "<<wages[j]<<endl; 
	}

    
   return 0;
  
 }
