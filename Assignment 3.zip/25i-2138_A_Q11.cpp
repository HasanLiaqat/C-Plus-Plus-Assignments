#include<iostream>
#include<cmath>
using namespace std;
int main()
{	
	int n,m;
	int rsum=0;
	int csum=0;

	cout<<"Rows of matrix: ";
	cin>>n;
	
	cout<<"Columns of matrix: ";
	cin>>m; 
	
	int arr[n][m];
	
	cout<<"Enter integers in matrices (rows*column): "<<endl;
	for (int i=0; i<n ; i++)
	{	
		for (int j=0; j<m ; j++)
		{
			cin>>arr[i][j];
		}
	}
	
	for (int i=0; i<n ; i++)
	{
		int min = arr[i][0];
		for (int j=1; j<m ; j++)
		{
			if (arr[i][j] < min)
			{
				min = arr[i][j];
			}
		}
	
		 rsum = rsum + min;	
	}
	
	for (int j=0; j<m ; j++)
	{
		 int max = arr[0][j];
		for (int i=1; i<n ; i++)
		{
			if (arr[i][j] > max)
			{
				max = arr[i][j];
			}
		}
	
		 csum = csum + max;	
	}
	
	float mean = floor( ( rsum + csum ) / float (n+m) );
	
	
	int count = 0;
	for (int i=0; i<n ; i++)
	{
		for (int j=0; j<m ; j++)
		{
			if ( arr[i][j] > mean )
			{
				count++;
			}
		}
	}
	
	cout<<"\nMean : "<<mean<<endl;
	cout<<"Number of Elements greater than mean : "<<count<<endl; 
	
	
   return 0;
}	
