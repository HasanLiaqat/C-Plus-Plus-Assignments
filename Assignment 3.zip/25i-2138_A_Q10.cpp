#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int arr[4][4];
	
	cout<<"Enter 16 numbers in 4*4 matrix: ";
	for (int i=0; i<4 ; i++)
	{
		for (int j=0; j<4 ; j++)
		{
			cin>>arr[i][j];
		}
	}
	
	int choice;
	
	cout<<"--------MENU-------"<<endl;
	cout<<"1. Total\n2. Average\n3. RowTotal\n4. ColumnTotal\n5. Highest in Row\n6. Lowest in Row\n7. Transpose\n8. Left Diagonal total\n9. Right Diagonal total\n10. Multiply\n";
	cout<<"\nSelect an option: ";
	cin>>choice;
	
	if ( choice < 1 || choice > 10)
	{
		cout<<"Invalid Choice!"<<endl;
		return 0;
	}
	
	switch (choice)
	{
		case 1:
		{
			int sum=0;
			for (int i=0; i<4 ; i++)
			{
				for (int j=0; j<4 ; j++)
				{
					sum = sum + arr[i][j];
				}	
			} 
			
			cout<<"SUM : "<<sum<<endl;
			break;
			
		}
		
		case 2:
		{
			float sum=0.00;
			for (int i=0; i<4 ; i++)
			{
				for (int j=0; j<4 ; j++)
				{
					sum = sum + arr[i][j];
				}	
			} 
			
			float avg=0.00;
			avg = sum / 16;
			cout<< fixed << setprecision(2) <<"Average : "<<avg<<endl;
			break;	
		}
		
		case 3:
		{	
			int rown;
			cout<<"\n0 for row1\n1 for row2\n2 for row3\n3 for row4\n\n";
			cout<<"Enter the row number you want to total (0-3): ";	
			cin>>rown;
			
			while ( rown < 0 || rown > 3 )
			{
				cout<<"Invalid Row Number!"<<endl;
				cout<<"Enter the row number again (0-3): ";
				cin>>rown;		
			}
			
			int sum=0;
			for (int j=0; j<4 ; j++)
			{
				sum = sum + arr[rown][j];
			}	
			
			cout<<"Sum of row "<<rown<<" is: "<<sum<<endl;
			break;
		}
		
		case 4:
		{
			int coln;
			cout<<"\n0 for column 1\n1 for column 2\n2 for column 3\n3 for column 4\n\n";
			cout<<"Enter the column number you want to total (0-3): ";	
			cin>>coln;
			
			while ( coln < 0 || coln > 3 )
			{
				cout<<"Invalid Column Number!"<<endl;
				cout<<"Enter the column number again (0-3): ";
				cin>>coln;		
			}
			
			int sum=0;
			for (int j=0; j<4 ; j++)
			{
				sum = sum + arr[j][coln];
			}	
			
			cout<<"Sum of column "<<coln<<" is: "<<sum<<endl;
			break;
		}
		
		case 5:
		{
			int rown;
			cout<<"\n0 for row1\n1 for row2\n2 for row3\n3 for row4\n\n";
			cout<<"Enter the row number to check the highest in that row (0-3): ";	
			cin>>rown;
			
			while ( rown < 0 || rown > 3 )
			{
				cout<<"Invalid Row Number!"<<endl;
				cout<<"Enter the row number again (0-3): ";
				cin>>rown;		
			}
			
			int max = arr[rown][0];
			for ( int i=0; i<4 ; i++ )
			{
				if ( arr[rown][i] > max )
				{
					max = arr[rown][i];
				}
			} 
			
			cout<<"Highest number in row "<<rown<<" is : "<<max<<endl;
			break;	
		}
		
		case 6:
		{
			int rown;
			cout<<"\n0 for row1\n1 for row2\n2 for row3\n3 for row4\n\n";
			cout<<"Enter the row number to check the highest in that row (0-3): ";	
			cin>>rown;
			
			while ( rown < 0 || rown > 3 )
			{
				cout<<"Invalid Row Number!"<<endl;
				cout<<"Enter the row number again (0-3): ";
				cin>>rown;		
			}
			
			int min = arr[rown][0];
			for ( int i=0; i<4 ; i++ )
			{
				if ( arr[rown][i] < min )
				{
					min = arr[rown][i];
				}
			} 
			
			cout<<"Lowest number in row "<<rown<<" is : "<<min<<endl;
			break;	
		}
		
		case 7:
		{
			int transpose[4][4];
			for (int i=0; i<4 ; i++)
			{
				for (int j=0 ; j<4 ; j++)
				{
					transpose[j][i] = arr[i][j];
				}
			}
			
			for (int i=0; i<4 ; i++)
			{
				for (int j=0; j<4 ; j++)
				{
					cout<<transpose[i][j]<<" ";
				}
				
			cout<<endl;	
				
			}
			
			break;	
		}		
		
		case 8:
		{	
			int sum=0;
			for (int i=0; i<4 ; i++)
			{
				sum = sum + arr[i][i];
			} 	
			
			cout<<"SUM of left diagonal is : "<<sum<<endl;
			break;
		}
		
		case 9:
		{
			int sum=0;
			for (int i=0; i<4 ; i++)
			{						
				sum = sum + arr[i][3-i];
			} 
			
			cout<<"SUM of right diagonal is : "<<sum<<endl;
			break;		 
		}
		
		case 10:
		{
			int arr1[4][4];
			
			cout<<"Enter 4*4 matrix to multiply : ";
			for (int i=0; i<4 ; i++)
				{
					for (int j=0; j<4 ; j++)
					{
						cin>>arr1[i][j];
					}
				}
				
			int arr2[4][4]={0};
			int sum=0;
			
			for (int i=0; i<4 ; i++)
			{
				for (int j=0; j<4 ; j++)
				{
					for (int k=0; k<4 ; k++)
					{
						arr2[i][j] = arr2[i][j] + arr[i][k] * arr1[k][j];						
					}
				}
				
			}
			
			cout<<"\nResultant Matrix is: "<<endl;
			for (int i=0; i<4 ; i++)
			{
				for (int j=0; j<4 ; j++)	
				{
					cout<<arr2[i][j]<<" ";
  			        }
		
			cout<<endl;
		
			}	
			
			break;	
		}		
	
			default:
			{
				cout<<"Invalid Choice!"<<endl;
			}
	}		
	
   return 0;
}
	
