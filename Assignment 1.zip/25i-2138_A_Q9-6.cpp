#include<iostream>
using namespace std;
int main()
{
  unsigned int num;
  cout <<"Enter a 8-bit value: ";
  cin >> num;
  
  num = num & 255;   
  // TO KEEP INPUT WITHIN 8 BIT
  
  int count=0;
  int temp = num;
  
  while (temp>0)
  {   if (temp&1)                                     // CHECK IF BIT IS ONE 
  {   count = count + 1;
  }
     temp = temp >> 1;
   }
   
   int parity;
   
   if (count%2==0)
   cout <<"Parity: 1";
   else                                                // CHECK PARITY
   cout <<"Parity: 0";
   
   int inverted = (~num) & 255;
   cout <<"\nInverted value: " << inverted <<endl;       // INVERTING BITS
   
   return 0;
   
   }
   
    
