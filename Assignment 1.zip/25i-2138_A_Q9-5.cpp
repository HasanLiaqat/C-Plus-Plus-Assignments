#include<iostream>
using namespace std;
int main()
{
  int value;
  cout <<"Enter a 8-bit value: ";
  cin >> value;
  
  if ( value & ( 1 << (8-2) ) )
  cout <<"2nd Bit is one 1";            // CHECKING 2ND BIT
  else
  cout <<"\n2nd Bit is zero 0";
  
  if ( value & ( 1 << (8-5) ) )
  cout <<"\n5th Bit is one 1";            // CHECKING 5TH BIT
  else
  cout <<"\n5th Bit is zero 0";
  
  
  value = value ^ ( 1 << 5);            // TOGGLING 6TH BIT
  
  cout <<"\nValue after toggling 6th Bit: " << value <<endl;
  
  return 0;
  
  }
  
  
  
  
