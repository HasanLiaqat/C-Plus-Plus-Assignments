#include<iostream>
using namespace std;
int main()
{
  int totalminutes;
  cout << "Enter total minutes used: ";
  cin >> totalminutes;
  
  int hours=totalminutes/60;
  int minutes=totalminutes%60;
  
  float bill=(hours*50.0)+(minutes/60.0)*50.0;
  
  cout <<"Hours: " << hours <<endl;
  cout <<"Minutes: " << minutes <<endl;
  cout <<"Total Bill: Rs. " <<bill <<endl;
  
  return 0;
  
  
  
  }
  
