#include<iostream>
using namespace std;
int main()
{
  int pin;
  int key=9876;
  
  cout <<"Enter your 4 digit PIN: ";
  cin >> pin;
  
  int masked=pin ^ key;
  int obfuscated=masked << 2;
  
  cout <<"Original Pin: " << pin <<endl;
  cout <<"Masked: " << masked <<endl;
  cout <<"Obfuscated: " << obfuscated<<endl;
  
  cout <<"\n---Reverse Process---\n\n";
  int unobfuscated=obfuscated >> 2;
  int unmasked=unobfuscated ^ key;
  
 cout <<"Reversed/Original pin: " << unmasked <<endl;
 cout <<"\n";
 
    return 0;
    
    }
