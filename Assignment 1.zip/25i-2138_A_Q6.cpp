#include <iostream>
using namespace std;
int main()
{
  int mask;

 cout<<"Enter permission mask (0–255): ";
 cin>>mask;

   if(mask<0 || mask>255)
  cout<<"Invalid input. Please enter a number between 0 and 255.";
      // TO BE WITHIN RANGE

   cout<<"\n\"Permissions granted\" : ";

  if(mask & (1<<0)) 
  cout <<"\n✔ Read Files";
  if(mask & (1<<1))
  cout <<"\n✔ Write Files";
  if(mask & (1<<2)) 
  cout <<"\n✔ Execute Files";
  if(mask & (1<<3)) 
  cout <<"\n✔ Delete Files";
  if(mask & (1<<4)) 
  cout <<"\n✔ Modify Settings";
  if(mask & (1<<5)) 
  cout <<"\n✔ Access Logs";
  if(mask & (1<<6))
  cout <<"\n✔ Manage Users";
  if(mask & (1<<7)) 
  cout <<"\n✔ Admin Privileges"<<endl;

     int mask2 = mask ^ (1<<1);
      cout <<"\nToggle 'Write Files' permission:";      // APPLYING XOR TO TOOGLE
      cout <<"\nNew mask: "<<mask2<<endl;

      cout <<"\nCheck 'Manage Users' permission:";
     if(mask & (1<<6))
    cout <<"\nPermission granted."<<endl;
     else
    cout <<"\nPermission not granted"<<endl;

     mask = mask & ~(1<<3);
    cout <<"\n'Revoke Delete Files' permission:";     // USING NOT ~ TO REVOKE OR CHANGE
    cout <<"\nUpdated mask: "<<mask;
    cout <<"\n";
    
return 0;
}
