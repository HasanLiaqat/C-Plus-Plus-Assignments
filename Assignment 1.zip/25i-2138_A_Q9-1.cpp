#include<iostream>
using namespace std;
int main()
{
  char character;
  
  cout <<"Enter the character to encrypt: ";
  cin >> character;
  
  char encrypted=(character+5)%128;                          // %128 SO THAT VALUE DONT EXCEED 128 AS IT IS ASCII LIMIT
  cout <<"Encrypted character: " << encrypted<<endl;
  
  char decrypted=(encrypted-5)%128;                           // %128 TO AVOID NEGATIVE
  cout <<"Decrypted character: " << decrypted<<endl;
  
  return 0;
  
  }
