#include<iostream>
using namespace std;
int main()
{
  int basicsalary;
  
  cout <<"Enter your Basic Salary: ";
  cin >> basicsalary;
  
  float finalsalary = ((basicsalary * 1.5) + 500);
  float aftertax = (finalsalary * 0.1);
  float totalsalary = finalsalary - aftertax;
  
  cout <<"Final salary after tax: " << totalsalary <<endl;
  
  return 0;
  
  }
  
