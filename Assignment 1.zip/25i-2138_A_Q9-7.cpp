#include<iostream>
using namespace std;
int main()
{
  int integer;
  
  cout <<"Enter a number: ";
  cin >> integer;
  
  integer = integer << 4; 
  // RIGHT SHIFT BY 4 MEANS ( INTEGER * 2^4=16 )
  
  int finalinteger = integer + 250;
  
  cout <<"Final result: " << finalinteger <<endl;
  return 0;
  
  }
