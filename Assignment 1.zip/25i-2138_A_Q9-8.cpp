#include<iostream>
using namespace std;
int main()
{
  int integer;
  
  cout <<"Enter a number: ";
  cin >> integer;
  
  integer = integer % 256;
  int finalinteger = integer + 100;
  int finalresult = finalinteger % 256;
  
  cout <<"Final result: " << finalresult <<endl;
  
  return 0;
  
  }
