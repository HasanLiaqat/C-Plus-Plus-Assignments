#include <iostream>
#include<iomanip>
using namespace std;
int main()
{
  int year;
  string month;
  float totalamount;
  
  cout << "Enter the Month: ";
  cin >> month;
  
  cout << "Enter the Year: ";
  cin >> year;
  
  cout << "Total Amount collected: ";
  cin >> totalamount;
  
  float statetax=0.5;
  float countytax=0.2;
  float totaltax=0.7;
  
  float sales=totalamount/1+totaltax;
  float statesalestax=sales*statetax;
  float countysalestax=sales*countytax;
  float totalsalestax=statesalestax+countysalestax;
  
  cout << fixed << setprecision(2);
  cout <<"\nMonth: " << month <<" " << year <<endl;
  cout <<"--------------------------\n";
  cout <<"Total Collected : " << totalamount <<endl;
  cout <<"Sales           : " << sales <<endl;
  cout <<"County Sales Tax: " << countysalestax <<endl;
  cout <<"State Sales Tax : " << statesalestax <<endl;
  cout <<"Total Sales Tax : " << totalsalestax <<endl;
  
  return 0;
  
  } 
  
  
  
  
  
  
  
  
  
  
  
  
