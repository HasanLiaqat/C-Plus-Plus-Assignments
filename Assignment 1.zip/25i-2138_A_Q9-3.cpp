#include<iostream>
using namespace std;
int main()
{
  int value;
  cout <<"Enter 8-bit value: ";
  cin >> value;
  
  unsigned char leftrotation = ( value << 3) | ( value >> (8-3));
  // LEFT ROTATION OF 3 BITS AND AT THE END WRAP IS USED
  
  unsigned char rightrotation = ( value >> 3) | ( value << (8-3));
  // RIGHT ROTATION OF 3 BITS 
  
  unsigned char rotation = leftrotation ^ rightrotation;
  
  cout <<"Result after combining rotation: " << (int)rotation <<endl;
  // USED INT SO IT CAN PRINT NUMERIC VALUE AND NOT GARBAGE VALUE
  
  return 0;
  
  }
  
