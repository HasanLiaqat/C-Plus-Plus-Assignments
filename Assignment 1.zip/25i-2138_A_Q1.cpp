#include<iostream>
using namespace std;
int main()
{
  int amount;
  cout << "Enter amount in rupees:";
  cin >> amount;
  
  
  int n2000,n500,n200,n100,n50,n20,n10,n1;
  
  n2000=amount/2000;
  amount=amount%2000;
  
  n500=amount/500;
  amount=amount%500;
  
  n200=amount/200;
  amount=amount%200;
  
  n100=amount/100;
  amount=amount%100;
  
  n50=amount/50;
  amount=amount%50;
  
  n20=amount/20;
  amount=amount%20;
  
  n10=amount/10;
  amount=amount%10;
  
  n1=amount/1;
  amount=amount%1;
  
  cout << "\nCurrency Note : Number\n";
  cout << "2000          : " <<  n2000 << endl;
  cout << "500           : " <<  n500 << endl;
  cout << "200           : " <<  n200 << endl;
  cout << "100           : " <<  n100 << endl; 
  cout << "50            : " <<  n50 << endl; 
  cout << "20            : " <<  n20 << endl;
  cout << "10            : " <<  n10 << endl;
  cout << "1             : " <<  n1 << endl; 
  
  return 0;
  
  }
  
  
