#include<iostream>
using namespace std;
int main()
{
  char a;
  int key1,key2,key3;
  
  cout <<"Enter a character to encrypt: ";
  cin >> a;
  
  cout <<"Enter three keys (0-255): ";
  cin >> key1 >> key2 >> key3;
  
  char encrypted = a ^ key1 ^ key2 ^ key3;
  
  cout <<"Encrypted Character: " << encrypted <<endl;
  
  char decrypted = encrypted ^ key1 ^ key2 ^ key3;
  
  cout <<"Decrypted Character: " << decrypted<<endl;
  
  return 0;
  
  }
  
  
  
 
