#include<iostream>
using namespace std;
int main()
{
  int n;
  cout <<"Enter four digits number: ";
  cin >> n;
  
  int thousands=n/1000;
  int hundreds=(n/100)%10;
  int tens=(n/10)%10;
  int ones=n%10;
  
  int sum=thousands+hundreds+tens+ones;
  
  if (sum%10==0)
  cout <<"Checksum is VALID" <<endl;
  else
  cout <<"Checksum is INVALID" <<endl;
  
  return 0;
  
  }
  
  
  
  
  
