#include<iostream>
#include<string>
using namespace std;
  int main()
{
  long long code;
  string name;
  
  cout << "Enter agent code number (0-4294967295): ";
  cin >> code;
  
  cout <<"Enter your name: ";
  cin >> name;
  
  int unit=code & 63;                                      // bits=2^n-1=63  here unit is 6 bits
  int operation=(code >> 6) & 4095;                        // 2^12-1=4095   here operation uses 12 bits
  int mission=(code >> 18) & 63;
  int clearance=(code >> 24) & 255;                        // 2^8-1=255  clearance use 8 bits
  
  cout <<"\n--------------------------\n";
  cout <<"Name     : " << name <<endl;
  cout <<"Clearance: " << clearance <<endl;
  cout <<"Mission  : " << mission <<endl;
  cout <<"Operation: " << operation <<endl;
  cout <<"Unit     : " << unit <<endl;
  
  return 0;
  
  }
