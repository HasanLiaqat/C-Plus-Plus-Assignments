#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
   unsigned int header,type,port;
   
  cout <<"\nEnter packet header (in hexadecimal) = ";
  cin >> hex >> header;
  
   type = header >> 28;
   port = (header >> 16) & 0xFFF;      // APPLYING MASK
   
  cout <<"\nPacket Type = "<<type<<endl;
  cout <<"\nDestination Port = "<<port<<endl;

   if(type == 15 || port < 1024)
   cout <<"\nSuspicious packet flagged for review";
   else
    cout <<"\nPacket looks normal";
    cout <<"\n";

return 0;  

}

